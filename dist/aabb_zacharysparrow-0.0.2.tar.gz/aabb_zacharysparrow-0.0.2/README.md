# AABBCD
Axis Aligned Bounding Box for Continuous Distributions
